package st;

import static org.junit.Assert.*;

import org.junit.Test;

public class Task3_TDD1 {
	
	@Test
	public void test() {
	}
}
