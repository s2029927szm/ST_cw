package st;

import static org.junit.Assert.*;

import org.junit.Test;

public class Task2_2_FunctionalTest {
	
	@Test
	public void test() {
	}
}
