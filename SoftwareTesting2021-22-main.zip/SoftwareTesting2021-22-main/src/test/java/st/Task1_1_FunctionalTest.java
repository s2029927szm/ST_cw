package st;

import static org.junit.Assert.*;

import org.junit.Test;

public class Task1_1_FunctionalTest {

	@Test
	public void test() {
	}

}
