package st;

import static org.junit.Assert.*;

import org.junit.Test;

public class Task3_TDD2 {

	@Test
	public void test() {
	}

}
