package st;

public enum Type {
	  INTEGER,
	  BOOLEAN,
	  STRING,
	  CHARACTER,
	  NOTYPE
	};